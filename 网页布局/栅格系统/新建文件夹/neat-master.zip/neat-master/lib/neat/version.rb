module Neat
  VERSION = "1.8.0"
end
