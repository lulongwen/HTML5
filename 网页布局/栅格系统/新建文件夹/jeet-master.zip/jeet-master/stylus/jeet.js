module.exports = function(opts) {
  return function(style) {
    style.include(__dirname);
  }
}
