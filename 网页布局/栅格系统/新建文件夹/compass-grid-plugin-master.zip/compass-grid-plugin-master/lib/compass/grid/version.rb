module Compass
  module Grid
    VERSION = '0.0.6'
  end
end