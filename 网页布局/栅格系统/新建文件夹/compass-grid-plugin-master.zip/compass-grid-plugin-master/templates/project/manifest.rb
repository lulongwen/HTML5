description "Sass Grid based on the 1KB CSS Grid"

stylesheet 'screen.scss', :media => "screen, projection"
stylesheet 'partials/_base.scss'

help %Q{
Please see the website for all documentation and tutorials:

    https://github.com/heygrady/1KB-SCSS-Grid
}

welcome_message %Q{
Please see the website for all documentation and tutorials:

    https://github.com/heygrady/1KB-SCSS-Grid

}