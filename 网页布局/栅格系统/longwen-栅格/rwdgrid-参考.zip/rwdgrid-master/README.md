# rwdgrid - Responsive Grid System for your Next Project

www.rwdgrid.com 

www.rwdgrid.com/demo

rwdgrid is just another Grid system based on popular 960grid, which is responsive and ranges from mobile, tablet, laptops and 
wide screen displays. Naming convention is very similar to 960 grid system, where underscore is replaced by hyphen (increases readabilty).
rwdgrid is having different Grid system made for 1200px+, 1024px+, 720px+ and Mobile screens. 

This can be used as a base grid system that will help you to build responsive webdesign with your existing proficency over popular grid system

Sincere thanks to 960.gs,Html Shiv (HTML5 IE enabling script),
css3 Mediaqueries js (Mediaqueries IE enabling script - Don't forget the existing web!),
Html5 boilerplate and you! :)

rwdgrid is free to use and abuse under WTFPL


